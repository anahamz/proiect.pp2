#include <iostream>
#include <vector>
#include <string>
#include <cstring>
#include <conio.h>
#include "C:\Users\Ana\Desktop\PP\Clasa\Joc.h"
#include "C:\Users\Ana\Desktop\PP\Clasa\Bundle.h"

using namespace std;

void meniu(vector<Joc> &jocuri, vector<Bundle> &bundle);
void afisareJocuri(const vector<Joc>& jocuri);
void adaugareJocuri(vector<Joc> &jocuri, vector<Bundle> &bundle);
void stergereJocuri(vector<Joc> &jocuri, vector<Bundle> &bundle, const string& n = "");
void modificareJocuri(vector<Joc> &jocuri, vector<Bundle> &bundle);
void afisareBundle(const std::vector<Bundle> &bundle);
void adaugareBundle(std::vector<Bundle> &bundle, std::vector<Joc> &jocuri);
void stergereBundle(std::vector<Bundle> &bundle, std::vector<Joc> &jocuri, const std::string& n = "");

int main(int argc, char** argv) {
    vector<Joc> jocuri;
    vector<Bundle> bundle;
    Joc::citire(jocuri);
    Bundle::citire(bundle);
    if (argc > 1) {
        if (strcmp(argv[1], "-afisare") == 0) {
            afisareJocuri(jocuri);
            afisareBundle(bundle);
        } else if (argc == 3 && strcmp(argv[1], "-sterge") == 0) {
            stergereJocuri(jocuri, bundle, argv[2]);
        } else if (strcmp(argv[1], "-adauga") == 0) {
            adaugareJocuri(jocuri, bundle);
        } else if (strcmp(argv[1], "-modifica") == 0) {
            modificareJocuri(jocuri, bundle);
        } else if (argc == 3 && strcmp(argv[1], "-adaugaBundle") == 0) {
            adaugareBundle(bundle, jocuri);
        } else if (argc == 3 && strcmp(argv[1], "-stergeBundle") == 0) {
            stergereBundle(bundle, jocuri, argv[2]);
        } else {
            cout << "Comanda invalida!" << endl;
        }
    } else {
        meniu(jocuri, bundle);
    }

    return 0;
}

void meniu(vector<Joc> &jocuri, vector<Bundle> &bundle) {
    int optiune;
    do {
        system("cls");
        cout << "1. Adaugare joc" << endl;
        cout << "2. Stergere joc" << endl;
        cout << "3. Modificare joc" << endl;
        cout << "4. Afisare jocuri" << endl;
        cout << "5. Adaugare bundle" << endl;
        cout << "6. Stergere bundle" << endl;
        cout << "7. Afisare bundle" << endl;
        cout << "0. Iesire" << endl;
        cout << "Optiune: ";
//        cin >> optiune;
        optiune = getch() - '0';
        cout << endl;
        switch (optiune) {
            case 1:
                system("cls");
                adaugareJocuri(jocuri, bundle);
                break;
            case 2:
                system("cls");
                stergereJocuri(jocuri, bundle);
                break;
            case 3:
                system("cls");
                modificareJocuri(jocuri, bundle);
                break;
            case 4:
                system("cls");
                afisareJocuri(jocuri);
                break;
            case 5:
                system("cls");
                adaugareBundle(bundle, jocuri);
                break;
            case 6:
                system("cls");
                stergereBundle(bundle, jocuri);
                break;
            case 7:
                system("cls");
                afisareBundle(bundle);
                break;
            case 0:
                system("cls");
                cout << "La revedere!" << endl;
                break;
            default:
                cout << "Optiune invalida!" << endl;
        }
        if (optiune != 0) {
            cout << endl << "Apasati orice tasta pentru a continua...";
            getch();
        }
    } while (optiune != 0);
}

void afisareJocuri(const vector<Joc>& jocuri) {
    cout << "Jocuri:" << endl << endl;
    for (int i = 0; i < jocuri.size(); ++i) {
        cout << jocuri[i] << endl;
    }
}

void adaugareJocuri(vector<Joc> &jocuri, vector<Bundle> &bundle) {
    Joc joc;
    string denumire, categorie;
    double pret;
    int memorie;
    bool cumparat, instalat;
    cout << "Nume: ";
    fflush(stdin);
    getline(cin, denumire);
    joc.setDenumire(denumire);
    cout << "Categorie: ";
    fflush(stdin);
    getline(cin, categorie);
    joc.setCategorie(categorie);
    cout << "Pret: ";
    cin >> pret;
    joc.setPret(pret);
    cout << "Memorie: ";
    cin >> memorie;
    joc.setMemorie(memorie);
//    cout << "Cumparat: ";
//    cin >> cumparat;
    cumparat = false;
    joc.setCumparat(cumparat);
//    cout << "Instalat: ";
//    cin >> instalat;
    instalat = false;
    joc.setInstalat(instalat);
    jocuri.push_back(joc);
    Joc::scriere(jocuri);
    Bundle::scriere(bundle);
}

void stergereJocuri(vector<Joc> &jocuri, vector<Bundle> &bundle, const string& n) {
    string nume = n;
    if (nume.empty()) {
        cout << "Nume: ";
        fflush(stdin);
        getline(cin, nume);
    }
    for (int i = 0; i < jocuri.size(); ++i) {
        if (jocuri[i].getDenumire() == nume) {
            jocuri.erase(jocuri.begin() + i);
            break;
        }
    }
    Joc::scriere(jocuri);
    Bundle::scriere(bundle);
}

void modificareJocuri(vector<Joc> &jocuri, vector<Bundle> &bundle) {
    string nume;
    cout << "Nume: ";
    fflush(stdin);
    getline(cin, nume);
    string denumire, categorie;
    double pret;
    int memorie;
    bool cumparat, instalat;
    for (int i = 0; i < jocuri.size(); ++i) {
        if (nume == jocuri[i].getDenumire()) {
            cout << "Nume nou joc: ";
            fflush(stdin);
            getline(cin, denumire);
            jocuri[i].setDenumire(denumire);
            cout << "Categorie noua joc: ";
            fflush(stdin);
            getline(cin, categorie);
            jocuri[i].setCategorie(categorie);
            cout << "Pret nou joc: ";
            cin >> pret;
            jocuri[i].setPret(pret);
            cout << "Memorie noua joc: ";
            cin >> memorie;
            jocuri[i].setMemorie(memorie);
            cout << "Cumparat nou joc: ";
            cin >> cumparat;
            jocuri[i].setCumparat(cumparat);
            cout << "Instalat nou joc: ";
            cin >> instalat;
            jocuri[i].setInstalat(instalat);
            break;
        }
    }
    Joc::scriere(jocuri);
    Bundle::scriere(bundle);
}

void afisareBundle(const std::vector<Bundle> &bundle) {
    for (int i = 0; i < bundle.size(); ++i) {
        std::cout << bundle[i];
    }
}

void adaugareBundle(std::vector<Bundle> &bundle, std::vector<Joc> &jocuri) {
    std::cout << "Acestea sunt jocurile:" << std::endl;
    for (int i = 0; i < jocuri.size(); ++i) {
        std::cout << jocuri[i].getDenumire() << std::endl;
    }
    string nume;
    std::cout << "\nIntroduceti numele bundle-ului: ";
    std::getline(cin, nume);
    std::cout << "Introduceti numarul de jocuri din bundle: ";
    int n;
    std::cin >> n;
    std::vector<Joc> jocuriBundle;
    for (int i = 0; i < n; ++i) {
        std::string s;
        std::cout << "Introduceti numele jocului: ";
        fflush(stdin);
        getline(std::cin, s);
        bool ok = false;
        for (int j = 0; j < jocuri.size(); ++j) {
            if (jocuri[j].getDenumire() == s) {
                jocuriBundle.push_back(jocuri[j]);
                ok = true;
            }
        }
        if (!ok) {
            std::cout << "Jocul nu exista!" << std::endl;
            --i;
        }
    }
    std::cout << "Introduceti pretul special: ";
    int pret;
    std::cin >> pret;
    Bundle b(nume, jocuriBundle, pret);
    bundle.push_back(b);
    Joc::scriere(jocuri);
    Bundle::scriere(bundle);
}

void stergereBundle(std::vector<Bundle> &bundle, std::vector<Joc> &jocuri, const std::string& n) {
    std::string s = n;
    if (s.empty()) {
        std::cout << "Introduceti numele bundle-ului pe care doriti sa il stergeti: ";
        std::cin >> s;
    }
    for (int i = 0; i < bundle.size(); ++i) {
        if (bundle[i].getDenumire() == s) {
            bundle.erase(bundle.begin() + i);
        }
    }
    Joc::scriere(jocuri);
    Bundle::scriere(bundle);
}
