#include <iostream>
#include <vector>
#include <string>
#include <cstring>
#include <conio.h>
#include "C:\Users\Ana\Desktop\PP\Clasa\Joc.h"
#include "C:\Users\Ana\Desktop\PP\Clasa\Bundle.h"

using namespace std;

#define MAX 512

int spatiu = 0;

void meniu(vector<Joc> &jocuri, vector<Bundle> &bundle);
void afisareCatalog(const vector<Joc>& jocuri, const vector<Bundle>& bundle);
void cumparare(vector<Joc> &jocuri, vector<Bundle> &bundle, const string& n = "");
void instalare(vector<Joc> &jocuri, const string& n = "", int m = -1);
void dezinstalare(vector<Joc> &jocuri, const string& n = "", int m = -1);
int si(const string& s);

int main(int argc, char** argv) {
    vector<Joc> jocuri;
    vector<Bundle> bundle;
    Joc::citire(jocuri);
    Bundle::citire(bundle);
    if (argc > 1) {
        if (strcmp(argv[1], "-afisare") == 0) {
            afisareCatalog(jocuri, bundle);
        } else if (argc == 3 && strcmp(argv[1], "-cumparare") == 0) {
            cumparare(jocuri, bundle, argv[2]);
        } else if (argc == 3 && strcmp(argv[1], "-instalare") == 0) {
            instalare(jocuri, argv[2]);
        } else if(argc == 4 && strcmp(argv[1], "-instalare") == 0) {
            instalare(jocuri, argv[2], si(argv[4]));
        } else if (argc == 3 && strcmp(argv[1], "-dezinstalare") == 0) {
            dezinstalare(jocuri, argv[2]);
        } else if(argc == 4 && strcmp(argv[2], "-dezinstalare") == 0) {
            dezinstalare(jocuri, argv[2], si(argv[3]));
        } else {
            cout << "Comanda invalida!" << endl;
        }
    } else {
        meniu(jocuri, bundle);
    }

    return 0;
}

void meniu(vector<Joc> &jocuri, vector<Bundle> &bundle) {
    int optiune;
    do {
        system("cls");
        cout << "1. Afisare catalog" << endl;
        cout << "2. Cumparare joc" << endl;
        cout << "3. Instalare joc" << endl;
        cout << "4. Dezinstalare joc" << endl;
        cout << "0. Iesire" << endl;
        cout << "Optiune: ";
//        cin >> optiune;
        optiune = getch() - '0';
        cout << endl;
        switch (optiune) {
            case 1:
                system("cls");
                afisareCatalog(jocuri, bundle);
                break;
            case 2:
                system("cls");
                cumparare(jocuri, bundle);
                break;
            case 3:
                system("cls");
                instalare(jocuri);
                break;
            case 4:
                system("cls");
                dezinstalare(jocuri);
                break;
            case 0:
                system("cls");
                cout << "La revedere!" << endl;
                break;
            default:
                cout << "Optiune invalida!" << endl;
                break;
        }
        if (optiune != 0) {
            cout << endl << "Apasati orice tasta pentru a continua...";
            getch();
        }
    } while (optiune != 0);
}

void afisareCatalog(const vector<Joc>& jocuri, const vector<Bundle>& bundle) {
    // afisarea jocurilor pe categorii dupa care se afiseaza si bundle-urile
    vector<string> categorii;
    for (int i = 0; i < jocuri.size(); i++) {
        bool exista = false;
        for (int j = 0; j < categorii.size(); j++) {
            if (categorii[j] == jocuri[i].getCategorie()) {
                exista = true;
                break;
            }
        }
        if (!exista) {
            categorii.push_back(jocuri[i].getCategorie());
        }
    }
    for (int i = 0; i < categorii.size(); i++) {
        cout << categorii[i] << endl;
        for (int j = 0; j < jocuri.size(); j++) {
            if (jocuri[j].getCategorie() == categorii[i]) {
                cout << jocuri[j] << endl;
            }
        }
        cout << endl;
    }
    for (int i = 0; i < bundle.size(); i++) {
        cout << bundle[i];
    }
}

void cumparare(vector<Joc> &jocuri, vector<Bundle> &bundle, const string& n) {
    string nume;
    if (n.empty()) {
        cout << "Introduceti numele jocului: ";
        fflush(stdin);
        getline(cin, nume);
    } else {
        nume = n;
    }
    for (int i = 0; i < jocuri.size(); i++) {
        if (jocuri[i].getDenumire() == nume) {
            if (jocuri[i].getCumparat()) {
                cout << "Jocul este deja cumparat!" << endl;
                return;
            }
            jocuri[i].setCumparat(true);
            return;
        }
    }
    cout << "Jocul nu exista!" << endl;
}

void instalare(vector<Joc> &jocuri, const string& n, int m) {
    string nume;
    if (n.empty()) {
        cout << "Introduceti numele jocului: ";
        fflush(stdin);
        getline(cin, nume);
    } else {
        nume = n;
    }
    if (m != -1) {
        spatiu = m;
    }
    for (int i = 0; i < jocuri.size(); i++) {
        if (jocuri[i].getDenumire() == nume) {
            if (!jocuri[i].getCumparat()) {
                cout << "Jocul nu este cumparat!" << endl;
                return;
            } else if (jocuri[i].getInstalat()) {
                cout << "Jocul este deja instalat!" << endl;
                return;
            } else if (jocuri[i].getMemorie() + spatiu > MAX) {
                cout << "Nu aveti suficient spatiu pe disc!" << endl;
                return;
            }
            jocuri[i].setInstalat(true);
            spatiu += jocuri[i].getMemorie();
            return;
        }
    }
    cout << "Jocul nu exista!" << endl;
}

void dezinstalare(vector<Joc> &jocuri, const string& n, int m) {
    string nume;
    if (n.empty()) {
        cout << "Introduceti numele jocului: ";
        fflush(stdin);
        getline(cin, nume);
    } else {
        nume = n;
    }
    if (m != -1) {
        spatiu = m;
    }
    for (int i = 0; i < jocuri.size(); i++) {
        if (jocuri[i].getDenumire() == nume) {
            if (!jocuri[i].getCumparat()) {
                cout << "Jocul nu este cumparat!" << endl;
                return;
            } else if (!jocuri[i].getInstalat()) {
                cout << "Jocul nu este instalat!" << endl;
                return;
            }
            jocuri[i].setInstalat(false);
            spatiu -= jocuri[i].getMemorie();
            return;
        }
    }
    cout << "Jocul nu exista!" << endl;
}

int si(const string& s) {
    int nr = 0;
    for (int i = 0; i < s.size(); i++) {
        nr = nr * 10 + (s[i] - '0');
    }
    return nr;
}
