#include <fstream>
#include <iomanip>
#include "Bundle.h"

Bundle::Bundle() {
    this->denumire = "";
    this->jocuri = std::vector<Joc>();
    this->pretSpecial = 0;
}

Bundle::Bundle(const std::string& nume, std::vector<Joc> &jocuri, int pretSpecial) {
    this->denumire = nume;
    this->jocuri = jocuri;
    this->pretSpecial = pretSpecial;
}

Bundle::Bundle(const Bundle &bundle) {
    this->denumire = bundle.denumire;
    this->jocuri = bundle.jocuri;
    this->pretSpecial = bundle.pretSpecial;
}

void Bundle::citire(std::vector<Bundle> &bundle) {
    std::ifstream fin(fisier);
    if (!fin.is_open()) {
        std::cout << "Fisierul nu exista!" << std::endl;
        std::cout << "Creare fisier..." << std::endl;
        std::ofstream fout(fisier);
        fout.close();
        std::cout << "Fisier creat!" << std::endl;
        fin.close();
        return;
    }
    if (fin.eof()) {
        std::cout << "Fisierul nu contine jocuri!" << std::endl;
        fin.close();
        return;
    }
    int n = 0;
    fin >> n;
    if (fin.eof()) {
        std::cout << "Fisierul nu contine jocuri!" << std::endl;
        fin.close();
        return;
    }
    std::vector<Joc> jocuri;
    Joc joc;
    for (int i = 0; i < n; ++i) {
        fin >> joc;
        jocuri.push_back(joc);
    }
    fin >> n;
    Joc temp;
    int m;
    Bundle b;
    for (int i = 0; i < n; ++i) {
        fin >> b.denumire;
        fin >> b.pretSpecial;
        bundle.push_back(b);
        fin >> m;
        for (int j = 0; j < m; ++j) {
            fin >> temp;
            bundle[i].jocuri.push_back(temp);
        }
    }
    fin.close();
}

void Bundle::scriere(std::vector<Bundle> &bundle) {
    std::ofstream fout(fisier, std::ios::app);
    fout << bundle.size() << std::endl;
    for (int i = 0; i < bundle.size(); ++i) {
        fout << bundle[i].denumire << std::endl;
        fout <<  bundle[i].pretSpecial << std::endl;
        fout << bundle[i].jocuri.size() << std::endl;
        for (int j = 0; j < bundle[i].jocuri.size(); ++j) {
            fout << bundle[i].jocuri[i].getDenumire() << std::endl << bundle[i].jocuri[i].getMemorie() << std::endl
                 << bundle[i].jocuri[i].getPret()<< std::endl << bundle[i].jocuri[i].getInstalat()<< std::endl<< bundle[i].jocuri[i].getCumparat()
                 << std::endl << bundle[i].jocuri[i].getCategorie() << std::endl;
        }
    }
    fout.close();
}

std::ostream &operator<<(std::ostream &os, const Bundle &bundle) {
    os << std::setw(15) << std::left << bundle.denumire << "Pret: " << bundle.pretSpecial << std::endl << std::endl;
    for (int i = 0; i < bundle.jocuri.size(); ++i) {
        os << bundle.jocuri[i] << std::endl;
    }
    return os;
}

std::istream &operator>>(std::istream &is, Bundle &bundle) {
    is >> std::ws;
    std::getline(is, bundle.denumire);
    int n;
    is >> n;
    is.get();
    for (int i = 0; i < n; ++i) {
        Joc joc;
        is >> joc;
        bundle.jocuri.push_back(joc);
    }
    is >> bundle.pretSpecial;
    return is;
}

Bundle &Bundle::operator=(const Bundle &bundle) {
    this->denumire = bundle.denumire;
    this->jocuri = bundle.jocuri;
    this->pretSpecial = bundle.pretSpecial;
    return *this;
}
