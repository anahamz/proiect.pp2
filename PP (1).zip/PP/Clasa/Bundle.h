#ifndef MENIUNOU_BUNDLE_H
#define MENIUNOU_BUNDLE_H

#include <iostream>
#include <vector>
#include "Joc.h"

class Bundle {
private:
    std::string denumire;
    std::vector<class Joc> jocuri;
    int pretSpecial;

public:
    Bundle();
    Bundle(const std::string& nume, std::vector<Joc> &jocuri, int pretSpecial);
    Bundle(const Bundle& bundle);
    static void citire(std::vector<Bundle>& bundle);
    static void scriere(std::vector<Bundle>& bundle);
//    static void afisare(const std::vector<Bundle>& bundle);
//    static void adaugare(std::vector<Bundle>& bundle, std::vector<Joc>& jocuri);
//    static void stergere(std::vector<Bundle>& bundle, std::vector<Joc>& jocuri);

    std::string getDenumire() const { return denumire; };
    std::vector<Joc> getJocuri() const { return jocuri; };
    int getPretSpecial() const { return pretSpecial; };
    void setDenumire(const std::string& Denumire) { this->denumire = Denumire; };
    void setJocuri(std::vector<Joc>& Jocuri) { this->jocuri = Jocuri; };
    void setPretSpecial(int PretSpecial) { this->pretSpecial = PretSpecial; };
    friend std::ostream &operator<<(std::ostream &os, const Bundle &bundle);
    friend std::istream &operator>>(std::istream &is, Bundle &bundle);
    Bundle &operator=(const Bundle &bundle);

};


#endif //MENIUNOU_BUNDLE_H
