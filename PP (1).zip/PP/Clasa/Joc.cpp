#include <iostream>
#include <fstream>
#include <iomanip>
#include "Joc.h"

Joc::Joc() {
    this->memorie = 0;
    this->denumire = "";
    this->pret = 0;
    this->instalat = false;
    this->cumparat = false;
    this->categorie = "";
}

Joc::Joc(int memorie, std::string& denumire, double pret, bool instalat, bool cumparat, std::string& categorie) {
    this->memorie = memorie;
    this->denumire = denumire;
    this->pret = pret;
    this->instalat = instalat;
    this->cumparat = cumparat;
    this->categorie = categorie;
}

Joc::Joc(const Joc &joc) {
    this->memorie = joc.memorie;
    this->denumire = joc.denumire;
    this->pret = joc.pret;
    this->instalat = joc.instalat;
    this->cumparat = joc.cumparat;
    this->categorie = joc.categorie;
}

Joc &Joc::operator=(const Joc &joc) {
    this->memorie = joc.memorie;
    this->denumire = joc.denumire;
    this->pret = joc.pret;
    this->instalat = joc.instalat;
    this->cumparat = joc.cumparat;
    this->categorie = joc.categorie;
    return *this;
}

void Joc::citire(std::vector<Joc>& jocuri) {
    std::ifstream fin(fisier);
    if (!fin.is_open()) {
        std::cout << "Fisierul nu exista!" << std::endl;
        std::cout << "Creare fisier..." << std::endl;
        std::ofstream fout(fisier);
        fout.close();
        std::cout << "Fisier creat!" << std::endl;
        return;
    }
    if (fin.eof()) {
        std::cout << "Fisierul este gol!" << std::endl;
        return;
    }
    int n;
    fin >> n;
    for (int i = 0; i < n; ++i) {
        Joc joc;
        fin >> joc;
        jocuri.push_back(joc);
    }
    fin.close();
}

void Joc::scriere(std::vector<Joc>& jocuri) {
    std::ofstream fout(fisier);
    fout << jocuri.size() << std::endl;
    for (int i = 0; i < jocuri.size(); ++i) {
        fout << jocuri[i].denumire << std::endl << jocuri[i].memorie << std::endl
       << jocuri[i].pret<< std::endl << jocuri[i].instalat<< std::endl<< jocuri[i].cumparat
       << std::endl << jocuri[i].categorie << std::endl;
    }
}

std::ostream& operator<<(std::ostream &os, const Joc &joc) {
    os << std::setw(15) << std::left << "Nume: " << joc.denumire << std::endl;
    os << std::setw(15) << std::left << "Categorie: " << joc.categorie << std::endl;
    os << std::setw(15) << std::left << "Pret: " << joc.pret<< std::endl;
    os << std::setw(15) << std::left << "Memorie: " << joc.memorie << std::endl;
    os << std::setw(15) << std::left << "Instalat: " << (joc.instalat ? "Da" : "Nu") << std::endl;
    os << std::setw(15) << std::left << "Cumparat: " << (joc.cumparat ? "Da" : "Nu") << std::endl;
    return os;
}

std::istream &operator>>(std::istream &is, Joc &joc) {
    is >> std::ws;
    std::getline(is, joc.denumire);
    is >> joc.memorie;
    is >> joc.pret;
    is >> joc.instalat;
    is >> joc.cumparat;
    is >> std::ws;
    std::getline(is, joc.categorie);
    return is;
}
