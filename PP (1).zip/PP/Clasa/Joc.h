#ifndef MENIUNOU_JOC_H
#define MENIUNOU_JOC_H

#include <iostream>
#include "Bundle.h"

#define fisier "C:/Proiect/Clasa/jocuri.txt"

class Joc {
private:
    std::string denumire;
    int memorie;
    double pret;
    bool instalat;
    bool cumparat;
    std::string categorie;

public:
    Joc();
    Joc(int memorie, std::string& denumire, double pret, bool instalat, bool cumparat, std::string& categorie);
    Joc(const Joc &joc);
    static void citire(std::vector<Joc>& jocuri);
    static void scriere(std::vector<Joc>& jocuri);
//    static void meniu(std::vector<Joc>& jocuri, std::vector<class Bundle>& bundle);
//    static void afisare(const std::vector<Joc>& jocuri);
//    static void adaugare(std::vector<Joc>& jocuri, std::vector<Bundle>& bundle);
//    static void stergere(std::vector<Joc>& jocuri, std::vector<Bundle>& bundle);
//    static void modificare(std::vector<Joc>& jocuri, std::vector<Bundle>& bundle);

    int getMemorie() const { return memorie; };
    std::string getDenumire() const { return denumire; };
    double getPret() const { return pret; };
    bool getInstalat() const { return instalat; };
    bool getCumparat() const { return cumparat; };
    std::string getCategorie() const { return categorie; };
    void setMemorie(int Memorie) { this->memorie = Memorie; };
    void setDenumire(std::string& Denumire) { this->denumire = Denumire; };
    void setPret(double Pret) { this->pret = Pret; };
    void setInstalat(bool Instalat) { this->instalat = Instalat; };
    void setCumparat(bool Cumparat) { this->cumparat = Cumparat; };
    void setCategorie(std::string& Categorie) { this->categorie = Categorie; };
    friend std::ostream &operator<<(std::ostream &os, const Joc &joc);
    friend std::istream &operator>>(std::istream &is, Joc &joc);
    Joc &operator=(const Joc &joc);

};


#endif //MENIUNOU_JOC_H
